<?php
    include_once('conn.php');
    if(@$_GET['serch'])
    {
        $src = $_GET['src'];
        $qry  = "SELECT * FROM `user` WHERE `firstname` LIKE '%$src%'";
    }
    else{
        $qry = "SELECT * FROM `user`";
    }
    $run = mysqli_query($conn,$qry);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View</title>
    <link rel="stylesheet" href="css/create.css">
</head>
<body>

    
    <form action="" method="GET">
        <table border="1" cellspacing="5" width="100%">
            <tr>
                <th>Search</th>
                <th><div class="box"><input type="text" name="src"></div></th>
        <th><div class="box1"><input type="submit" name="serch"></div></th>
        <th><button class="local"><a href="view.php">back</a></button></th>
    </tr>
</table>
</form>
<table border="1" width="100%">
    <tr>
        <td>Id</td>
        <td>First Name</td>
        <td>Last Name</td>
        <td>Phone Number</td>
        <td>Email</td>
        <td>Password</td>
        <td>Confirm Password</td>
        <td>Gender</td>
        <td>Date</td>
        <td>Address</td>
        <td>About Us</td>
        <td>Edit</td>
        <td>Delete</td>
    </tr>
    <?php
    while($row = mysqli_fetch_assoc($run)){
    ?>
        <tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo $row['firstname'];?></td>
            <td><?php echo $row['lastname'];?></td>
            <td><?php echo $row['phonenumber'];?></td>
            <td><?php echo $row['email'];?></td>
            <td><?php echo $row['password'];?></td>
            <td><?php echo $row['confirmpassword'];?></td>
            <td><?php echo $row['gender'];?></td>
            <td><?php echo $row['birthdate'];?></td>
            <td><?php echo $row['address'];?></td>
            <td><?php echo $row['aboutus'];?></td>
            <td><a href="create.php?id=<?php echo $row['id'];?>">Edit</a></td>
            <td><a href="delete.php?id=<?php echo $row['id'];?>">Delete</a></td>
        </tr>
        <?php
    }
    ?>
</table>
<table border="1" width="100%">
    <tr>
        <th><a href="create.php">Add New Data</a></th>
        <th><a href="login.php">Login Data</a></th>
    </tr>
</table>
</body>
</html>