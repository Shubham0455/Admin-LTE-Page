<?php
    include_once('conn.php');
    $userId = $_SESSION['user'];
    $qry = "SELECT * FROM `user_id` WHERE `receiver_id`= '$userId' AND `status` = 0";
    $run = mysqli_query($conn , $qry);
    if(@$_GET['id'])
    {
        $id = $_GET['id'];
        $qry2 = "UPDATE `user_id` SET `status` = '1' WHERE `id` = '$id'";
        $run1 = mysqli_query($conn , $qry2);
    }
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>View</title>
        <link rel="stylesheet" href="css/create.css">
    </head>
    <body>
    <p></p>
<table width="100%" border="1">
    <tr>
        <td>Id</td>
        <td>First Name</td>
        <td>Last Name</td>
        <td>Phone Number</td>
        <td>Email</td>
        <td>Password</td>
        <td>Confirm Password</td>
        <td>Gender</td>
        <td>Date</td>
        <td>Address</td>
        <td>About Us</td>
    </tr>
    <?php
    while($row = mysqli_fetch_assoc($run)){

        $id = $row['sender_id'];
        $qry1 = "SELECT * FROM `user` WHERE `id` = '$id'";
        $res = mysqli_query($conn , $qry1);
        $row1 = mysqli_fetch_assoc($res);
        $i = $row1['status'];
        ?>
        <?php
        if($i == 0)
        {
            ?>
            <tr>
            <td><?php echo $row1['id'];?></td>
            <td><?php echo $row1['firstname'];?></td>
            <td><?php echo $row1['lastname'];?></td>
            <td><?php echo $row1['phonenumber'];?></td>
            <td><?php echo $row1['email'];?></td>
            <td><?php echo $row1['password'];?></td>
            <td><?php echo $row1['confirmpassword'];?></td>
            <td><?php echo $row1['gender'];?></td>
            <td><?php echo $row1['birthdate'];?></td>
            <td><?php echo $row1['address'];?></td>
            <td><?php echo $row1['aboutus'];?></td>
            <td><a href="acceptedfriend.php?id=<?php echo $row['id'];?>">Accept</a></td>
            <td><a href="Editfriend.php?id=<?php echo $row['id'];?>">Reject</a></td>
        </tr>
        <?php
        }
        ?>
    <?php
    }
    ?>

</table>
</body>
</html>