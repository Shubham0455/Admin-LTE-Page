<?php
    include_once('conn.php');
    if(@$_GET['id'])
    {
        $id = $_GET['id'];
        $qry = "DELETE FROM `user` WHERE `id`='$id'";
        $run = mysqli_query($conn,$qry);
        header("location:view.php");
    }
?>