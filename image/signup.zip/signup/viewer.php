<?php
    include_once('conn.php');
    $userId = $_SESSION['user'];
    $qry = "SELECT * FROM `viewer`";
    $run = mysqli_query($conn , $qry);
    if(@$_GET['id'])
{
        $id = $_GET['id'];
        $qry2 = "SELECT * FROM `viewer` where `sender_id`= $userId AND `View_person`= $id";
        $run2 = mysqli_query($conn,$qry2);
        $show = mysqli_fetch_assoc($run2);
        if($show == null)
        {
            $qry = "INSERT INTO `viewer` (`sender_id`, `View_person`) VALUES ('$userId','$id')";
            $show = mysqli_query($conn,$qry);
        }
}
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>View</title>
        <link rel="stylesheet" href="css/create.css">
    </head>
    <body>
    <p></p>
<table border="1"">
    <?php
    while($row = mysqli_fetch_assoc($run)){
        
        $id = $row['View_person'];
        $qry1 = "SELECT * FROM `user` WHERE `id` = '$id'";
        $res = mysqli_query($conn , $qry1);
        $row1 = mysqli_fetch_assoc($res);
        $i = $row1['status'];
        ?>
        <?php
        if($i == 0)
        {
            ?>
            <tr><td>Id</td><td><?php echo $row1['id'];?></td></tr>
            <tr><td>First Name</td><td><?php echo $row1['firstname'];?></td></tr>
            <tr><td>Last Name</td><td><?php echo $row1['lastname'];?></td></tr>
            <tr><td>Phone Number</td><td><?php echo $row1['phonenumber'];?></td></tr>
            <tr><td>Email</td><td><?php echo $row1['email'];?></td></tr>
            <tr><td>Password</td><td><?php echo $row1['password'];?></td></tr>
            <tr><td>Confirm Password</td><td><?php echo $row1['confirmpassword'];?></td></tr>
            <tr><td>Gender</td><td><?php echo $row1['gender'];?></td></tr>
            <tr><td>Date</td><td><?php echo $row1['birthdate'];?></td></tr>
            <tr><td>Address</td><td><?php echo $row1['address'];?></td></tr>
            <tr><td>About Us</td><td><?php echo $row1['aboutus'];?></td></tr>
        <?php
        }
        ?>
    <?php
    }
    ?>
</table>
</body>
</html>