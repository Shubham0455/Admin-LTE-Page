<?php
include_once('conn.php');   
$userId = $_SESSION['user'];
if(@$_GET['id'])
{
        $id = $_GET['id'];
        $qry2 = "SELECT * FROM `user_id` where `sender_id`= $userId AND `receiver_id`= $id";
        $run2 = mysqli_query($conn,$qry2);
        $show = mysqli_fetch_assoc($run2);
        if($show == null)
        {
            $qry = "INSERT INTO `user_id` (`sender_id`, `receiver_id`) VALUES ('$userId','$id')";
            $run = mysqli_query($conn,$qry);
        }
        
        $qry3 = "UPDATE `user` SET `status`='1' WHERE `id` = $id";
        $run3 = mysqli_query($conn,$qry3);
}


if(!$_SESSION['user'])
{
    header("location:login.php");
}
if($userId)
{
    $qry = "SELECT * FROM `user` WHERE `id` = '$userId'";
    $run = mysqli_query($conn , $qry);
    $row = mysqli_fetch_assoc($run);
    ?>
    <table border="1" width="91.2%">
        <tr>
        <th>Id</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Password</th>
        <th>Confirm Password</th>
        <th>Gender</th>
        <th>Birth Date</th>
        <th>Address</th>
        <th>About Us</th>
    </tr>
    <tr>
        <td><?php echo $row['id'];?></td>
        <td><?php echo $row['firstname'];?></td>
        <td><?php echo $row['lastname'];?></td>
        <td><?php echo $row['phonenumber'];?></td>
        <td><?php echo $row['email'];?></td>
        <td><?php echo $row['password'];?></td>
        <td><?php echo $row['confirmpassword'];?></td>
        <td><?php echo $row['gender'];?></td>
        <td><?php echo $row['birthdate'];?></td>
        <td><?php echo $row['address'];?></td>
        <td><?php echo $row['aboutus'];?></td>
    </tr>
</table>
<?php
        }
        echo"<br>";
        echo"<br>";
        ?>
    <?php
        $qry = "SELECT * FROM `user` WHERE `id` != '$userId'";
        $run = mysqli_query($conn , $qry);
        ?>
        <table width="100%" border="1">
            <tr>
                <th>Id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Password</th>
                <th>Confirm Password</th>
                <th>Gender</th>
                <th>Birth Date</th>
                <th>Address</th>
                <th>About Us</th>
                <th>Request</th>
            </tr>
            <?php
    while($row = mysqli_fetch_assoc($run)){
        ?>
        <tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo $row['firstname'];?></td>
            <td><?php echo $row['lastname'];?></td>
            <td><?php echo $row['phonenumber'];?></td>
            <td><?php echo $row['email'];?></td>
            <td><?php echo $row['password'];?></td>
            <td><?php echo $row['confirmpassword'];?></td>
            <td><?php echo $row['gender'];?></td>
            <td><?php echo $row['birthdate'];?></td>
            <td><?php echo $row['address'];?></td>
            <td><?php echo $row['aboutus'];?></td>
            <td><?php $i = $row['status'];?>
                <?php 
                        if($i==1)
                        {
                            ?>
                            <a href="dashboard.php?id=<?php echo $row['id'];?>">RequestAdd</a>
                        <?php
                        }
                        else{
                        ?>
                        <a href="dashboard.php?id=<?php echo $row['id'];?>">Request</a>
                        <?php
                    }
                ?>
            </td>
        </tr>
        <?php
    }
    ?>
    </table>
    
    <div class="k"><h3><a href="logout.php">LOGOUT</a></h3>
    <h3><a href="Friend/insert.php">Add Friend</a></h3>
    <h3><a href="Friend/view.php">View Friend</a></h3>
    <h3><a href="Editfriend.php" target="_blank">Requested Friend</a></h3>
    <h3><a href="acceptedfriend.php" target="_blank">Accepted Friend</a></h3>
    <h3><a href="viewer.php">View Profile</a></h3></div>


    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>dashboard</title>
            <link rel="stylesheet" href="css/create.css">
        </head>
        <body>
            </body>
            </html>