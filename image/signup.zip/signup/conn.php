<?php
    $conn = mysqli_connect('localhost','root','','admin');
    session_start();
?>