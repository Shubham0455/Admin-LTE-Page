<?php
    include_once('conn.php');
    
    if(@$_GET['id'])
    {
        $id = $_GET['id'];
        $qry = "SELECT * FROM `user` WHERE `id` = '$id'";
        $run = mysqli_query($conn,$qry);
        $row = mysqli_fetch_assoc($run);
    }
    if(@$_POST['sub'])
    {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $phonenumber = $_POST['phonenumber'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirmpassword = $_POST['confirm_password'];
        $gender = $_POST['gender'];
        $birthdate = $_POST['bod'];
        $address = $_POST['address'];
        $aboutus = $_POST['aboutus'];
        if($password == $confirmpassword)
        {
            if(@$_GET['id'])
            {
                $qry = "UPDATE `user` SET `firstname`='$firstname',`lastname`='$lastname',`phonenumber`='$phonenumber',`email`='$email',`password`='$password',`confirmpassword`='$confirmpassword',`gender`='$gender',`birthdate`='$birthdate',`address`='$address',`aboutus`='$aboutus' WHERE `id` = '$id'";
            }
            else{
                $qry = "INSERT INTO `user`(`firstname`, `lastname`, `phonenumber`, `email`, `password`, `confirmpassword`, `gender`, `birthdate`, `address`, `aboutus`) VALUES ('$firstname','$lastname','$phonenumber','$email','$password','$confirmpassword','$gender','$birthdate','$address','$aboutus')";
            }
            $run = mysqli_query($conn,$qry);   
        }
        else
        {
            echo "Your password and confirmpassword is diffrent";
        }
            
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link rel="stylesheet" href="css/create.css">
</head>
<body>
    <div class="container">
        <h2>Signup Form</h2>
        <form action="" method="POST">
            <input type="text" name="firstname" placeholder="firstname" require value="<?php echo @$row['firstname'] ?>">
            <input type="text" name="lastname" placeholder="lastname" require value="<?php echo @$row['lastname'] ?>">
            <input type="text" name="phonenumber" placeholder="phonenumber" require value="<?php echo @$row['phonenumber'] ?>">
            <input type="email" name="email" placeholder="Email" require value="<?php echo @$row['email'] ?>">
            <input type="<?php if(@$_GET['id']){echo "text";}else{echo "password";} ?>" name="password" placeholder="Password" require value="<?php echo @$row['password'] ?>">
            <input type="<?php if(@$_GET['id']){echo "text";}else{echo "password";} ?>" name="confirm_password" placeholder="Confirm Password" require value="<?php echo @$row['confirmpassword'] ?>">
            <div class="flex">
                <span>Male<input type="radio" value="Male"<?php if(@$row['gender']=="Male"){echo "checked";} ?> name="gender">
                Female<input type="radio" value="Female"<?php if(@$row['gender']=="Female"){echo "checked";} ?> name="gender">
                Other<input type="radio" value="Other"<?php if(@$row['gender']=="Other"){echo "checked";} ?> name="gender"></span>
            </div>
            <input type="date" name="bod" require value="<?php echo @$row['birthdate'] ?>">
            <input type="text" name="address" placeholder="address" require value="<?php echo @$row['address'] ?>">
            <input type="text" name="aboutus" placeholder="aboutus" require value="<?php echo @$row['aboutus'] ?>">
            <input class="hi" type="submit" name="sub" value="<?php if(@$_GET['id']){echo "Update";}else{echo "Signup";} ?>">
        </form>
    </div>
    <table border="1" width="100%">
    <tr>
        <th><a href="view.php">View Your Data</a></th>
    </tr>
    </table>
</body>
</html>