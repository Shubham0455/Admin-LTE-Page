<?php
    include_once('conn.php');
    if(@$_POST['sub'])
    {
       
            $email = $_POST['email'];
           
            $password = $_POST['password'];

            $qry = "SELECT * FROM `user` WHERE `email`='$email' AND `password`='$password'";
            $res = mysqli_query($conn , $qry);

            $count = mysqli_num_rows($res);

            $row = mysqli_fetch_assoc($res);

            if($count == 1)
            {
                $_SESSION['user'] = $row['id'];
                header("location:dashboard.php");
            }
            else
            {
                echo "Invalid Data";
            }
            

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link rel="stylesheet" href="css/create.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form action="" method="POST">
            <input type="email" name="email" value="" placeholder="Email" require>
            <input type="password" name="password" value="" placeholder="Password" require>
            <input class="hi" type="submit" name="sub" id="" value="Submit">

        </form>
    </div>
    <table border="1" width="100%">
    <tr>
        <th><a href="view.php">View Your Data</a></th>
    </tr>
    </table>
</body>
</html>
<!-- https://bridge496.qodeinteractive.com/?_ga=2.251722889.1859700779.1726892568-1500908643.1726892568 -->