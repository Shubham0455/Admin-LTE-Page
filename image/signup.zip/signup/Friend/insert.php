<?php
    include_once('../conn.php');
    $userId = $_SESSION['user'];

    if(@$_GET['id'])
    {
      $qry = "SELECT * FROM `krishna` WHERE `id`='$userId'";
      $res = mysqli_query($conn ,$qry);
      $row = mysqli_fetch_assoc($res);

      $gen = $row['gender'];
      $file = $row['image'];
      $sel = $row['name'];

    }
    if(@$_POST['sub'])
    {
      // echo "<pre>";
      // print_r($_FILES['file']);die;
        $user = $_POST['num'];
        $phonenumber = $_POST['pn'];
        $gen = $_POST['gender'];
        $hob = $_POST['game'];
        $hb_str = implode(",",$hob);
        $file = $_FILES['file']['name'];
        $sel = $_POST['select'];
        if(@$_GET['id'])
        {
          $qry = "UPDATE `krishna` SET `gender`='$gen',`hobbies`='$hb_str',`image`='$file',`name`='$sel',`phonenumber`='$phonenumber',`F_id`='$user' WHERE `id`='$userId'";
        }
        else
        {
          move_uploaded_file($_FILES['file']['tmp_name'],"images/".$file);
          $qry = "INSERT INTO `krishna`(`gender`, `hobbies`, `image`, `name`, `phonenumber`,`F_id`) VALUES ('$gen','$hb_str','$file','$sel','$phonenumber','$user')";
        }
        $res = mysqli_query($conn , $qry);
      }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link rel="stylesheet" href="css/create.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form action="" method="POST" enctype="multipart/form-data">
          <div class="d-flex">
              <input type="text" name="num" value="<?php echo $userId ?>">
            </div>
          <div class="d-flex">
              <input type="text" name="pn"  placeholder="Enter Your Number" value="<?php echo @$row['phonenumber'] ?>">
            </div>
            <div class="d-flex">
              Male<input type="radio" name="gender" value="Male"<?php if(@$gen == 'Male') { echo 'checked';}?>>
              Female<input type="radio" name="gender" value="Female"<?php if(@$gen == 'Female') { echo 'checked';}?>>
              Other<input type="radio" name="gender" value="Other"<?php if(@$gen == 'Other') { echo 'checked';}?>>
            </div>
            <div class="d-flex">
              chess<input type="checkbox" name="game[]" value="chess">
              hockey<input type="checkbox" name="game[]" value="hockey">
            </div>
            <div class="d-flex">
              <input type="file" name="file" value="<?php if(@$file != null) { echo 'selected';}?>">
            </div>
              <div class="d-flex">
                <select name="select">
                    <option>Select Name</option>
                    <option value="Vraj"<?php if(@$sel == 'Vraj') { echo 'selected';}?>>Vraj</option>
                    <option value="Tushar"<?php if(@$sel == 'Tushar') { echo 'selected';}?>>Tushar</option>
                    <option value="Harsh"<?php if(@$sel == 'Harsh') { echo 'selected';}?>>Harsh</option>
                    <option value="Krish"<?php if(@$sel == 'Krish') { echo 'selected';}?>>Krish</option>
                    <option value="Viken"<?php if(@$sel == 'Viken') { echo 'selected';}?>>Viken</option>
                </select>
              </div>
              <div class="d-flex">
                <input type="submit" value="Submit" name="sub">
              </div>

              <div class="d-flex">      
                <a href="../dashboard.php">Edit Page</a>
              </div>
        </form>
    </div>
</body>
</html>
<!-- https://bridge496.qodeinteractive.com/?_ga=2.251722889.1859700779.1726892568-1500908643.1726892568 -->