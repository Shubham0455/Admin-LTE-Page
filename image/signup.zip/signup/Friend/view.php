<?php
    include_once('../conn.php');
    if(@$_GET['id'])
    {
        $id = $_GET['id'];
        $qry = "DELETE FROM `krishna` WHERE `id` = $id";
        $run = mysqli_query($conn,$qry); 
        header("location:view.php");
    }
    $userId = $_SESSION['user'];
    $qry = "SELECT * FROM `krishna` WHERE `F_id`= '$userId'";
    $run = mysqli_query($conn , $qry);

    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>View</title>
        <link rel="stylesheet" href="../css/create.css">
    </head>
    <body>

<table width="100%">
    <tr>
        <td>Id</td>
        <td>Phone Number</td>
        <td>gender</td>
        <td>hobbies</td>
        <td>image</td>
        <td>name</td>
        <td>Edit</td>
        <td>Delete</td>
    </tr>
    <?php
    while($row = mysqli_fetch_assoc($run)){
    ?>
        <tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo $row['phonenumber'];?></td>
            <td><?php echo $row['gender'];?></td>
            <td><?php echo $row['hobbies'];?></td>
            <td>
                <img src="images/<?php echo $row['image'];?>" alt="" width="50px" height="50px">
            </td>
            <td><?php echo $row['name'];?></td>
            <td><a href="insert.php?id=<?php echo $row['id']?>">Edit</a></td>
            <td><a href="view.php?id=<?php echo $row['id']?>">Delete</a></td>
        </tr>
    <?php
    }
    ?>

</table>
</body>
</html>